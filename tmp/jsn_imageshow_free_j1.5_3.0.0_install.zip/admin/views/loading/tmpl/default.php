<?php
/**
 * @author JoomlaShine.com Team
 * @copyright JoomlaShine.com
 * @link joomlashine.com
 * @package JSN ImageShow
 * @version 2.0
 * @license GNU/GPL v2 http://www.gnu.org/licenses/gpl-2.0.html
 */
defined('_JEXEC') or die( 'Restricted access' );

?>
<link rel="stylesheet" href="<?php echo JURI::root(true).'/administrator/components/com_imageshow/assets/css/imageshow.css';?>" type="text/css" />
<div class="jsn-loading-bg"></div>
<?php exit();?>